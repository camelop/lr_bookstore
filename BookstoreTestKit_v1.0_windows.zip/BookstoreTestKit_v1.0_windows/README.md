### 如何使用
windows环境下的评测脚本
编码使用ansi，换行符为windows风格，注意数据中输出“本”字时使用ansi
将可执行文件编译为```bookstore.exe```放在```judge.py```以及```test_data```同目录下并确保其拥有执行权限即可
测试命令：
```powershell
python judge.py
```
即可测试公开的8个数据点